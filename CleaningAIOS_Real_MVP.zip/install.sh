#!/usr/bin/env bash
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Запустите от root: sudo bash install.sh"
  exit 1
fi

read -r -p "Telegram bot token: " TELEGRAM_BOT_TOKEN
read -r -p "Ваш Telegram ID: " OWNER_TELEGRAM_ID
SERVER_IP=$(curl -4 -fsS https://api.ipify.org || hostname -I | awk '{print $1}')
POSTGRES_PASSWORD=$(openssl rand -hex 24)

cat > .env <<ENV
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
TELEGRAM_BOT_TOKEN=${TELEGRAM_BOT_TOKEN}
OWNER_TELEGRAM_ID=${OWNER_TELEGRAM_ID}
SERVER_IP=${SERVER_IP}
ENV
chmod 600 .env

docker compose up -d --build

echo "Ждём запуск системы..."
for i in {1..60}; do
  if curl -fsS http://127.0.0.1/health >/dev/null 2>&1; then
    echo "CleaningAI OS запущена: http://${SERVER_IP}"
    echo "Откройте Telegram-бота и нажмите Start."
    exit 0
  fi
  sleep 2
done

echo "Система не успела запуститься. Выполните: docker compose logs --tail=100"
exit 1
