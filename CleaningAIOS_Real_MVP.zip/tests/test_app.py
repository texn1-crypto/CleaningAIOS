import os
os.environ["DATABASE_URL"] = "sqlite:///./test_cleaningai.db"
from fastapi.testclient import TestClient
from app.main import app


def test_health():
    with TestClient(app) as client:
        r = client.get('/health')
        assert r.status_code == 200
        assert r.json()['status'] == 'ok'


def test_task_flow():
    with TestClient(app) as client:
        r = client.post('/api/tasks', json={'title': 'Проверить тендер'})
        assert r.status_code == 200
        task_id = r.json()['id']
        r = client.post(f'/api/tasks/{task_id}/complete')
        assert r.status_code == 200
