# CleaningAI OS — реальная рабочая версия 0.1

Это минимальный, но настоящий запускаемый продукт:

- FastAPI backend;
- PostgreSQL;
- веб-панель Mission Control;
- задачи;
- очередь решений API;
- Telegram-бот через polling;
- Docker Compose;
- автоматический install.sh.

## Запуск

```bash
unzip CleaningAIOS_Real_MVP.zip
cd CleaningAIOS_Real_MVP
bash install.sh
```

После запуска:

- веб: `http://IP_СЕРВЕРА`
- Telegram: `/start`, `/dashboard`, `/tasks`, `/decisions`, `/addtask текст`

Это не весь ранее задуманный продукт. Это первая реальная основа, которую можно запустить сегодня и расширять релизами.
