from contextlib import asynccontextmanager
from fastapi import Depends, FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .config import settings
from .db import Base, SessionLocal, engine
from .models import Decision, Task
from .schemas import DecisionCreate, TaskCreate


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)
    yield


app = FastAPI(title=settings.app_name, version="0.1.0", lifespan=lifespan)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.get("/health")
def health():
    return {"status": "ok", "app": settings.app_name, "version": "0.1.0"}


@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db)):
    open_tasks = db.scalar(select(func.count(Task.id)).where(Task.status == "open")) or 0
    pending_decisions = db.scalar(select(func.count(Decision.id)).where(Decision.status == "pending")) or 0
    return {
        "company_health": 82,
        "open_tasks": open_tasks,
        "pending_decisions": pending_decisions,
        "message": "Система запущена и готова принимать реальные данные.",
    }


@app.get("/api/tasks")
def list_tasks(db: Session = Depends(get_db)):
    rows = db.scalars(select(Task).order_by(Task.id.desc())).all()
    return [
        {"id": r.id, "title": r.title, "status": r.status, "priority": r.priority}
        for r in rows
    ]


@app.post("/api/tasks")
def create_task(payload: TaskCreate, db: Session = Depends(get_db)):
    row = Task(title=payload.title, priority=payload.priority)
    db.add(row)
    db.commit()
    db.refresh(row)
    return {"id": row.id, "title": row.title, "status": row.status, "priority": row.priority}


@app.post("/api/tasks/{task_id}/complete")
def complete_task(task_id: int, db: Session = Depends(get_db)):
    row = db.get(Task, task_id)
    if not row:
        raise HTTPException(status_code=404, detail="Task not found")
    row.status = "done"
    db.commit()
    return {"ok": True}


@app.get("/api/decisions")
def list_decisions(db: Session = Depends(get_db)):
    rows = db.scalars(select(Decision).order_by(Decision.id.desc())).all()
    return [
        {"id": r.id, "title": r.title, "rationale": r.rationale, "status": r.status}
        for r in rows
    ]


@app.post("/api/decisions")
def create_decision(payload: DecisionCreate, db: Session = Depends(get_db)):
    row = Decision(title=payload.title, rationale=payload.rationale)
    db.add(row)
    db.commit()
    db.refresh(row)
    return {"id": row.id, "title": row.title, "rationale": row.rationale, "status": row.status}


@app.post("/api/decisions/{decision_id}/{action}")
def decide(decision_id: int, action: str, db: Session = Depends(get_db)):
    if action not in {"approve", "reject", "defer"}:
        raise HTTPException(status_code=400, detail="Unsupported action")
    row = db.get(Decision, decision_id)
    if not row:
        raise HTTPException(status_code=404, detail="Decision not found")
    row.status = {"approve": "approved", "reject": "rejected", "defer": "deferred"}[action]
    db.commit()
    return {"ok": True, "status": row.status}


@app.get("/", response_class=HTMLResponse)
def index():
    return """
<!doctype html><html lang='ru'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>CleaningAI OS</title><style>
body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;background:#0f172a;color:#e2e8f0;margin:0;padding:24px}.wrap{max-width:980px;margin:auto}.card{background:#1e293b;border-radius:18px;padding:20px;margin:12px 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}.big{font-size:34px;font-weight:700}.muted{color:#94a3b8}button{background:#2563eb;color:white;border:0;border-radius:10px;padding:10px 14px}input{padding:11px;border-radius:10px;border:1px solid #475569;background:#0f172a;color:white;width:70%}
</style></head><body><div class='wrap'><h1>CleaningAI OS</h1><p class='muted'>Реальная рабочая версия 0.1</p><div id='dash' class='grid'></div><div class='card'><h2>Новая задача</h2><input id='task' placeholder='Например: проверить тендер №145'><button onclick='addTask()'>Добавить</button></div><div class='card'><h2>Задачи</h2><div id='tasks'></div></div></div>
<script>
async function load(){const d=await fetch('/api/dashboard').then(r=>r.json());dash.innerHTML=`<div class=card><div class=big>${d.company_health}%</div><div class=muted>Здоровье компании</div></div><div class=card><div class=big>${d.open_tasks}</div><div class=muted>Открытые задачи</div></div><div class=card><div class=big>${d.pending_decisions}</div><div class=muted>Решения</div></div>`; const t=await fetch('/api/tasks').then(r=>r.json());tasks.innerHTML=t.map(x=>`<p>#${x.id} ${x.title} — ${x.status}</p>`).join('')||'<p class=muted>Пока задач нет</p>'}
async function addTask(){const title=task.value.trim();if(!title)return;await fetch('/api/tasks',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title})});task.value='';load()}load();
</script></body></html>
"""
