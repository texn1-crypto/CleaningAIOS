import logging

import httpx
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, ContextTypes

from .config import settings

logging.basicConfig(level=logging.INFO)
BASE = "http://web:8000"


def allowed(update: Update) -> bool:
    if not settings.owner_telegram_id:
        return True
    uid = update.effective_user.id if update.effective_user else 0
    return str(uid) == str(settings.owner_telegram_id)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        await update.effective_message.reply_text("Доступ не разрешён.")
        return
    keyboard = [
        [InlineKeyboardButton("🏢 Mission Control", callback_data="dashboard")],
        [InlineKeyboardButton("🧾 Задачи", callback_data="tasks"), InlineKeyboardButton("✅ Решения", callback_data="decisions")],
    ]
    await update.effective_message.reply_text(
        "CleaningAI OS запущена. Выберите раздел:",
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


async def dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    async with httpx.AsyncClient(timeout=10) as client:
        data = (await client.get(f"{BASE}/api/dashboard")).json()
    text = (
        f"🏢 Состояние компании: {data['company_health']}%\n"
        f"🧾 Открытые задачи: {data['open_tasks']}\n"
        f"✅ Решения: {data['pending_decisions']}\n\n"
        f"{data['message']}"
    )
    await update.effective_message.reply_text(text)


async def addtask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return
    title = " ".join(context.args).strip()
    if not title:
        await update.effective_message.reply_text("Использование: /addtask Текст задачи")
        return
    async with httpx.AsyncClient(timeout=10) as client:
        data = (await client.post(f"{BASE}/api/tasks", json={"title": title, "priority": "normal"})).json()
    await update.effective_message.reply_text(f"Задача #{data['id']} создана: {data['title']}")


async def tasks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    async with httpx.AsyncClient(timeout=10) as client:
        rows = (await client.get(f"{BASE}/api/tasks")).json()
    if not rows:
        await update.effective_message.reply_text("Задач пока нет.")
        return
    text = "🧾 Задачи:\n" + "\n".join(f"#{x['id']} {x['title']} — {x['status']}" for x in rows[:20])
    await update.effective_message.reply_text(text)


async def decisions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    async with httpx.AsyncClient(timeout=10) as client:
        rows = (await client.get(f"{BASE}/api/decisions")).json()
    if not rows:
        await update.effective_message.reply_text("Решений на согласовании пока нет.")
        return
    text = "✅ Решения:\n" + "\n".join(f"#{x['id']} {x['title']} — {x['status']}" for x in rows[:20])
    await update.effective_message.reply_text(text)


async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.data == "dashboard":
        await dashboard(update, context)
    elif q.data == "tasks":
        await tasks(update, context)
    elif q.data == "decisions":
        await decisions(update, context)


def main():
    if not settings.telegram_bot_token:
        raise RuntimeError("TELEGRAM_BOT_TOKEN is empty")
    app = Application.builder().token(settings.telegram_bot_token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("dashboard", dashboard))
    app.add_handler(CommandHandler("tasks", tasks))
    app.add_handler(CommandHandler("decisions", decisions))
    app.add_handler(CommandHandler("addtask", addtask))
    app.add_handler(CallbackQueryHandler(callback))
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
