from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "CleaningAI OS"
    database_url: str = "sqlite:///./cleaningai.db"
    telegram_bot_token: str = ""
    owner_telegram_id: str = ""
    public_base_url: str = "http://localhost:8000"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
